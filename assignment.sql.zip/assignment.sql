select * from employee2;

select * from employee2 e where e.emp_id=105;